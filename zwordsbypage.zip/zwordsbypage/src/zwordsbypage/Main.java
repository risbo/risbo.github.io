package zwordsbypage;

public class Main {
	public static void main(String[] args) {
		Process p=new Process();
		MainPage mainPage=p.getMainPage("www.nytimes.com");
//		System.out.println(p.getContent("https://sourcemaking.com/design_patterns/builder/java/2"));
//		for(String line:mainPage.getSubList()) {
//			System.out.println(line);
//		}
		for(String line:p.getContextText()) {
			System.out.println(line);
		} 
	}
}
