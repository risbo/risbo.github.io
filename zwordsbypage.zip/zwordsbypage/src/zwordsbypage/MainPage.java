package zwordsbypage;

import java.util.ArrayList;
import java.util.List;

public class MainPage {
	private String main;
	private List<String> subList; 

	public String getMain() {
		return main;
	}

	public void setMain(String main) {
		this.main = main;
	}

	public List<String> getSubList() {
		if(subList==null) {
			subList=new ArrayList<String>();
		}
		return subList;
	}

	public void setSubList(List<String> subList) {
		this.subList = subList;
	}

}
