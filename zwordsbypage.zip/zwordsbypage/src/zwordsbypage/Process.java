package zwordsbypage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class Process {

	private String getContent(String url) {
		String content = "";
		try {
			content = org.apache.commons.io.IOUtils.toString(new URL(url), "utf8");

		} catch (Exception e) {
			e.printStackTrace();
		}
//		return content;
		return loadTextFile(url);
	}
	 
	private List<String> listWithUrls(String url){
		String content=getContent(url);
		content=content
				.replaceAll("href=", "\nhref=")
				.replaceAll(".html", ".html\n");
		return Arrays.asList(
					content.split("\n")
				)
				.stream()
				.filter(line-> line!=null && !line.isEmpty() && line.contains("href=") && line.contains(".html") && !line.contains(url))
				.collect(Collectors.toList());
	}
	
	private List<String> getListLinks(String url){
		List<String> result=new ArrayList<String>();
		List<String> listSubLinks=listWithUrls(url);
		for(String line:listSubLinks) {
			line=line.replaceAll("href=\"", url);
			result.add(line);
		}
		return result;
	}
	
	public MainPage getMainPage(String url) {
		MainPage mainPage=new MainPage();
		mainPage.setMain(url);
		mainPage.getSubList().addAll(getListLinks(url));
		
		return mainPage;
		
	}
	
	public List<String> getContextText() {
		String html = loadTextFile("www.nytimes.com");
		html=html.toLowerCase();
		Document doc = Jsoup.parse(html); 
		List<String> resultWords=Arrays.asList(doc.body().text().split("\\s"));
		resultWords=resultWords.stream().filter(
				line->{
					String textRegex = "[a-z]{3,20}";
					Pattern pattern = Pattern.compile(textRegex, Pattern.CASE_INSENSITIVE);
					Matcher matcher = pattern.matcher(line);
					if(line!=null 
							&& !line.isEmpty() 
							&& line.length()>3
							&& matcher.matches())
						return true;
					else return false;
				} 
				).distinct().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		return resultWords;
	}
	public static String loadTextFile(String url) {
	    try {
	        BufferedReader r = new BufferedReader(new FileReader(new File(url)));
	        StringWriter w = new StringWriter();

	        try {
	            String line = r.readLine();
	            while (null != line) {
	                w.append(line).append("\n");
	                line = r.readLine();
	            }

	            return w.toString();
	        } finally {
	            r.close();
	            w.close();
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();

	        return "";
	    }
	}
}
