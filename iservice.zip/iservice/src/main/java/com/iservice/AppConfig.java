package com.iservice;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource; 

 

@SpringBootApplication 
public class AppConfig extends SpringBootServletInitializer {
 
	public static void main(String[] args) {
		SpringApplication.run(AppConfig.class, args);
	}
	
	@Configuration
	@ComponentScan("com.iservice")
	public class SpringJdbcConfig {
	    @Bean
	    public DataSource mysqlDataSource() {
	        DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
	        dataSource.setUrl("jdbc:mysql://ec2-3-88-110-186.compute-1.amazonaws.com:3306/test");
	        dataSource.setUsername("admin");
	        dataSource.setPassword("admin");
	 
	        return dataSource;
	    }
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(AppConfig.class);
	}


	@Bean
	public Utils getUtils() {
		return new Utils();
	}

}
