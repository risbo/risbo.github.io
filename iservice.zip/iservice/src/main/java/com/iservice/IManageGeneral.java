package com.iservice;

public interface IManageGeneral {
	public void save(String valueJSON);
}
