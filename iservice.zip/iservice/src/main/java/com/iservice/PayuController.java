package com.iservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 

@RestController
@RequestMapping("/payu/")
public class PayuController {
	
	@Autowired
	private IManageGeneral manageGeneral;

	@PostMapping("/post/")
	@CrossOrigin(origins = "*", maxAge = 3600)
	public HttpStatus applyIva(@RequestBody ConfirmacionPayU confirmacionPayU) {
		
		 
		manageGeneral.save(Utils.toJson(confirmacionPayU));
		
		return HttpStatus.ACCEPTED;
	}
	
	@GetMapping("/get/")
	@CrossOrigin(origins = "*", maxAge = 3600)
	public HttpStatus listPCPlans() {		

		return HttpStatus.ACCEPTED;

	}
}
