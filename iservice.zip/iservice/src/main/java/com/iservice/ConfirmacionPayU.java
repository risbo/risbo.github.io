package com.iservice;

import java.io.Serializable;

public class ConfirmacionPayU implements Serializable {

	private static final long serialVersionUID = 1L;

	Integer merchant_id;
	String state_pol;
	Double risk;
	String response_code_pol;
	String reference_sale;
	String reference_pol;
	String sign;
	String extra1;
	String extra2;
	Integer payment_method;
	Integer payment_method_type;
	Integer installments_number;
	Integer value;
	Integer tax;
	Integer additional_value;
	String transaction_date;
	String currency;
	String email_buyer;
	String cus;
	String pse_bank;
	String test;
	String description;
	String billing_address;
	String shipping_address;
	String phone;
	String office_phone;
	String account_number_ach;
	String account_type_ach;
	Double administrative_fee;
	Double administrative_fee_base;
	Double administrative_fee_tax;
	String airline_code;
	Integer attempts;
	String authorization_code;
	String travel_agency_authorization_code;
	String bank_id;
	String billing_city;
	String billing_country;
	Double commision_pol;
	String commision_pol_currency;
	Integer customer_number;
	String date;
	String error_code_bank;
	String error_message_bank;
	Double exchange_rate;
	String ip;
	String nickname_buyer;
	String nickname_seller;
	Integer payment_method_id;
	String payment_request_state;
	String pseReference1;
	String pseReference2;
	String pseReference3;
	String response_message_pol;
	String shipping_city;
	String shipping_country;
	String transaction_bank_id;
	String transaction_id;

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}

	public String getState_pol() {
		return state_pol;
	}

	public void setState_pol(String state_pol) {
		this.state_pol = state_pol;
	}

	public Double getRisk() {
		return risk;
	}

	public void setRisk(Double risk) {
		this.risk = risk;
	}

	public String getResponse_code_pol() {
		return response_code_pol;
	}

	public void setResponse_code_pol(String response_code_pol) {
		this.response_code_pol = response_code_pol;
	}

	public String getReference_sale() {
		return reference_sale;
	}

	public void setReference_sale(String reference_sale) {
		this.reference_sale = reference_sale;
	}

	public String getReference_pol() {
		return reference_pol;
	}

	public void setReference_pol(String reference_pol) {
		this.reference_pol = reference_pol;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getExtra1() {
		return extra1;
	}

	public void setExtra1(String extra1) {
		this.extra1 = extra1;
	}

	public String getExtra2() {
		return extra2;
	}

	public void setExtra2(String extra2) {
		this.extra2 = extra2;
	}

	public Integer getPayment_method() {
		return payment_method;
	}

	public void setPayment_method(Integer payment_method) {
		this.payment_method = payment_method;
	}

	public Integer getPayment_method_type() {
		return payment_method_type;
	}

	public void setPayment_method_type(Integer payment_method_type) {
		this.payment_method_type = payment_method_type;
	}

	public Integer getInstallments_number() {
		return installments_number;
	}

	public void setInstallments_number(Integer installments_number) {
		this.installments_number = installments_number;
	}

	public Integer getValue() {
		return value;
	}

	public void setValue(Integer value) {
		this.value = value;
	}

	public Integer getTax() {
		return tax;
	}

	public void setTax(Integer tax) {
		this.tax = tax;
	}

	public Integer getAdditional_value() {
		return additional_value;
	}

	public void setAdditional_value(Integer additional_value) {
		this.additional_value = additional_value;
	}

	public String getTransaction_date() {
		return transaction_date;
	}

	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getEmail_buyer() {
		return email_buyer;
	}

	public void setEmail_buyer(String email_buyer) {
		this.email_buyer = email_buyer;
	}

	public String getCus() {
		return cus;
	}

	public void setCus(String cus) {
		this.cus = cus;
	}

	public String getPse_bank() {
		return pse_bank;
	}

	public void setPse_bank(String pse_bank) {
		this.pse_bank = pse_bank;
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBilling_address() {
		return billing_address;
	}

	public void setBilling_address(String billing_address) {
		this.billing_address = billing_address;
	}

	public String getShipping_address() {
		return shipping_address;
	}

	public void setShipping_address(String shipping_address) {
		this.shipping_address = shipping_address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getOffice_phone() {
		return office_phone;
	}

	public void setOffice_phone(String office_phone) {
		this.office_phone = office_phone;
	}

	public String getAccount_number_ach() {
		return account_number_ach;
	}

	public void setAccount_number_ach(String account_number_ach) {
		this.account_number_ach = account_number_ach;
	}

	public String getAccount_type_ach() {
		return account_type_ach;
	}

	public void setAccount_type_ach(String account_type_ach) {
		this.account_type_ach = account_type_ach;
	}

	public Double getAdministrative_fee() {
		return administrative_fee;
	}

	public void setAdministrative_fee(Double administrative_fee) {
		this.administrative_fee = administrative_fee;
	}

	public Double getAdministrative_fee_base() {
		return administrative_fee_base;
	}

	public void setAdministrative_fee_base(Double administrative_fee_base) {
		this.administrative_fee_base = administrative_fee_base;
	}

	public Double getAdministrative_fee_tax() {
		return administrative_fee_tax;
	}

	public void setAdministrative_fee_tax(Double administrative_fee_tax) {
		this.administrative_fee_tax = administrative_fee_tax;
	}

	public String getAirline_code() {
		return airline_code;
	}

	public void setAirline_code(String airline_code) {
		this.airline_code = airline_code;
	}

	public Integer getAttempts() {
		return attempts;
	}

	public void setAttempts(Integer attempts) {
		this.attempts = attempts;
	}

	public String getAuthorization_code() {
		return authorization_code;
	}

	public void setAuthorization_code(String authorization_code) {
		this.authorization_code = authorization_code;
	}

	public String getTravel_agency_authorization_code() {
		return travel_agency_authorization_code;
	}

	public void setTravel_agency_authorization_code(String travel_agency_authorization_code) {
		this.travel_agency_authorization_code = travel_agency_authorization_code;
	}

	public String getBank_id() {
		return bank_id;
	}

	public void setBank_id(String bank_id) {
		this.bank_id = bank_id;
	}

	public String getBilling_city() {
		return billing_city;
	}

	public void setBilling_city(String billing_city) {
		this.billing_city = billing_city;
	}

	public String getBilling_country() {
		return billing_country;
	}

	public void setBilling_country(String billing_country) {
		this.billing_country = billing_country;
	}

	public Double getCommision_pol() {
		return commision_pol;
	}

	public void setCommision_pol(Double commision_pol) {
		this.commision_pol = commision_pol;
	}

	public String getCommision_pol_currency() {
		return commision_pol_currency;
	}

	public void setCommision_pol_currency(String commision_pol_currency) {
		this.commision_pol_currency = commision_pol_currency;
	}

	public Integer getCustomer_number() {
		return customer_number;
	}

	public void setCustomer_number(Integer customer_number) {
		this.customer_number = customer_number;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getError_code_bank() {
		return error_code_bank;
	}

	public void setError_code_bank(String error_code_bank) {
		this.error_code_bank = error_code_bank;
	}

	public String getError_message_bank() {
		return error_message_bank;
	}

	public void setError_message_bank(String error_message_bank) {
		this.error_message_bank = error_message_bank;
	}

	public Double getExchange_rate() {
		return exchange_rate;
	}

	public void setExchange_rate(Double exchange_rate) {
		this.exchange_rate = exchange_rate;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getNickname_buyer() {
		return nickname_buyer;
	}

	public void setNickname_buyer(String nickname_buyer) {
		this.nickname_buyer = nickname_buyer;
	}

	public String getNickname_seller() {
		return nickname_seller;
	}

	public void setNickname_seller(String nickname_seller) {
		this.nickname_seller = nickname_seller;
	}

	public Integer getPayment_method_id() {
		return payment_method_id;
	}

	public void setPayment_method_id(Integer payment_method_id) {
		this.payment_method_id = payment_method_id;
	}

	public String getPayment_request_state() {
		return payment_request_state;
	}

	public void setPayment_request_state(String payment_request_state) {
		this.payment_request_state = payment_request_state;
	}

	public String getPseReference1() {
		return pseReference1;
	}

	public void setPseReference1(String pseReference1) {
		this.pseReference1 = pseReference1;
	}

	public String getPseReference2() {
		return pseReference2;
	}

	public void setPseReference2(String pseReference2) {
		this.pseReference2 = pseReference2;
	}

	public String getPseReference3() {
		return pseReference3;
	}

	public void setPseReference3(String pseReference3) {
		this.pseReference3 = pseReference3;
	}

	public String getResponse_message_pol() {
		return response_message_pol;
	}

	public void setResponse_message_pol(String response_message_pol) {
		this.response_message_pol = response_message_pol;
	}

	public String getShipping_city() {
		return shipping_city;
	}

	public void setShipping_city(String shipping_city) {
		this.shipping_city = shipping_city;
	}

	public String getShipping_country() {
		return shipping_country;
	}

	public void setShipping_country(String shipping_country) {
		this.shipping_country = shipping_country;
	}

	public String getTransaction_bank_id() {
		return transaction_bank_id;
	}

	public void setTransaction_bank_id(String transaction_bank_id) {
		this.transaction_bank_id = transaction_bank_id;
	}

	public String getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}

	@Override
	public String toString() {
		return "ConfirmacionPayU [merchant_id=" + merchant_id + ", state_pol=" + state_pol + ", risk=" + risk
				+ ", response_code_pol=" + response_code_pol + ", reference_sale=" + reference_sale + ", reference_pol="
				+ reference_pol + ", sign=" + sign + ", extra1=" + extra1 + ", extra2=" + extra2 + ", payment_method="
				+ payment_method + ", payment_method_type=" + payment_method_type + ", installments_number="
				+ installments_number + ", value=" + value + ", tax=" + tax + ", additional_value=" + additional_value
				+ ", transaction_date=" + transaction_date + ", currency=" + currency + ", email_buyer=" + email_buyer
				+ ", cus=" + cus + ", pse_bank=" + pse_bank + ", test=" + test + ", description=" + description
				+ ", billing_address=" + billing_address + ", shipping_address=" + shipping_address + ", phone=" + phone
				+ ", office_phone=" + office_phone + ", account_number_ach=" + account_number_ach
				+ ", account_type_ach=" + account_type_ach + ", administrative_fee=" + administrative_fee
				+ ", administrative_fee_base=" + administrative_fee_base + ", administrative_fee_tax="
				+ administrative_fee_tax + ", airline_code=" + airline_code + ", attempts=" + attempts
				+ ", authorization_code=" + authorization_code + ", travel_agency_authorization_code="
				+ travel_agency_authorization_code + ", bank_id=" + bank_id + ", billing_city=" + billing_city
				+ ", billing_country=" + billing_country + ", commision_pol=" + commision_pol
				+ ", commision_pol_currency=" + commision_pol_currency + ", customer_number=" + customer_number
				+ ", date=" + date + ", error_code_bank=" + error_code_bank + ", error_message_bank="
				+ error_message_bank + ", exchange_rate=" + exchange_rate + ", ip=" + ip + ", nickname_buyer="
				+ nickname_buyer + ", nickname_seller=" + nickname_seller + ", payment_method_id=" + payment_method_id
				+ ", payment_request_state=" + payment_request_state + ", pseReference1=" + pseReference1
				+ ", pseReference2=" + pseReference2 + ", pseReference3=" + pseReference3 + ", response_message_pol="
				+ response_message_pol + ", shipping_city=" + shipping_city + ", shipping_country=" + shipping_country
				+ ", transaction_bank_id=" + transaction_bank_id + ", transaction_id=" + transaction_id + "]";
	}
	
	

}

