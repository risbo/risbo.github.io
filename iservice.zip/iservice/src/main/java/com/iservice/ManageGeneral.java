package com.iservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class ManageGeneral implements IManageGeneral {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Override
	public void save(String valueJSON) {
		jdbcTemplate.update("insert into RESPONSE_PAYU (id, response) values(null,?)", valueJSON);

	}

}
