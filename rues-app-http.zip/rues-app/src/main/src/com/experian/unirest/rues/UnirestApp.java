package com.experian.unirest.rues;
import java.util.HashMap;
import java.util.Map;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest; 

public class UnirestApp {
	
	public static Object rues(String nit)  {
		try {
			Map<String, String> headers = new HashMap<>();
		    headers.put("accept", "application/json");
		    headers.put("X-Requested-With", "XMLHttpRequest");
		    headers.put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
		    headers.put("Origin", "https://www.rues.org.co");
		    headers.put("Sec-Fetch-Site", "same-origin");
		    headers.put("Sec-Fetch-Mode", "cors");
		    headers.put("Sec-Fetch-Dest", "empty");
		    headers.put("Referer", "https://www.rues.org.co/RM");
		    headers.put("Cookie", "__RequestVerificationToken=4kdRJS8c6f_GlaMvySt6du5JoycFopZgYSb0kEhOqy_G8SmsgpvjjnyVh83PQDpO8mOjmBENBvm5iu6Kr6AOoMrf3RJ1OzES_l4A-Sp9C5M1; _ga=GA1.3.1081409311.1600180117; _gid=GA1.3.1342792521.1600180117");
		 
		    Map<String, Object> fields = new HashMap<>();
		    fields.put("__RequestVerificationToken", "DjKhLALub0R1copNEKLqNAXFn2lAOvSI_LFSaMZ2V11Hi24-b2K-ElDrcJQqXRiyVSKUrSqnmagHOAKK060jSbZbG4GdhcxwMSLlc8O5XWg1");
		    fields.put("txtNIT", nit);
		 
		    HttpResponse<JsonNode> jsonResponse 
		      = Unirest.post("http://www.rues.org.co//RM/ConsultaNIT_json")
		      .headers(headers).fields(fields)
		      .asJson();
		    
		    return jsonResponse.getBody();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
//"900422614"
}
